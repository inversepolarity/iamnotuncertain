![](https://github.com/inversepolarity/iamnotuncertain/blob/master/icons/icon128.png)

## i am not uncertain
omnibar search → nth result. press escape to cancel.

## search engines supported

- google
- ddg
- kagi
- bing
- ecosia
- qwant
- brave search
- yahoo
- startpage
- yandex

![options](/options.png)

<!-- TODO: submit cws -->
<!-- TODO: submit ffstore -->
