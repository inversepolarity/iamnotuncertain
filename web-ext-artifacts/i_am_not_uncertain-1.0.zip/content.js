(function () {
  "use strict";

  let config = {
    enabled: true,
    resultIndex: 1,
    enabledEngines: {},
    showNotification: true,
  };

  let redirectCancelled = false;
  let redirectTimeout = null;
  let countdownInterval = null;

  // Detect current search engine
  function detectSearchEngine() {
    const hostname = window.location.hostname;
    const pathname = window.location.pathname;

    for (const [key, engine] of Object.entries(SEARCH_ENGINES)) {
      if (engine.domains.some((domain) => hostname.includes(domain))) {
        if (pathname.includes(engine.searchPath)) {
          return { key, engine };
        }
      }
    }
    return null;
  }

  // Check if current URL has a search query
  function hasSearchQuery(engine) {
    const params = new URLSearchParams(window.location.search);
    return (
      params.has(engine.queryParam) &&
      params.get(engine.queryParam).trim() !== ""
    );
  }

  // Extract Nth search result
  function extractNthResult(engine, n) {
    for (const selector of engine.selectors) {
      try {
        const links = Array.from(document.querySelectorAll(selector));

        // Filter out excluded patterns
        const validLinks = links.filter((link) => {
          const href = link.href;
          if (!href || href === window.location.href) return false;

          return !engine.excludePatterns.some((pattern) =>
            href.toLowerCase().includes(pattern.toLowerCase())
          );
        });

        // Remove duplicates
        const uniqueLinks = [];
        const seenUrls = new Set();

        for (const link of validLinks) {
          const url = link.href;
          if (!seenUrls.has(url)) {
            seenUrls.add(url);
            uniqueLinks.push(link);
          }
        }

        if (uniqueLinks.length >= n) {
          return uniqueLinks[n - 1].href;
        }
      } catch (e) {
        console.error("Error with selector:", selector, e);
      }
    }

    return null;
  }

  // Create and show notification overlay
  function showRedirectNotification(resultUrl, index, delay) {
    if (!config.showNotification) return;

    // Remove any existing notification
    const existing = document.getElementById("search-notification");
    if (existing) {
      existing.remove();
    }

    const notification = document.createElement("div");
    notification.id = "search-notification";
    notification.innerHTML = `
      <div style="
        position: fixed;
        top: 20px;
        right: 20px;
        background: #1a1a1a;
        color: white;
        padding: 16px 20px;
        border-radius: 8px;
        box-shadow: 0 2px 16px rgba(0, 0, 0, 0.2);
        z-index: 999999;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        font-size: 14px;
        min-width: 340px;
        max-width: 400px;
        animation: slideIn 0.3s ease;
        border: 1px solid rgba(255, 255, 255, 0.1);
      ">
        <style>
          @keyframes slideIn {
            from { transform: translateX(400px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
          }
          @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(400px); opacity: 0; }
          }
          @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
          }
          .lucky-search-fade-out {
            animation: slideOut 0.3s ease !important;
          }
        </style>
        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
          <div style="
            width: 20px;
            height: 20px;
            border: 2px solid rgba(255, 255, 255, 0.2);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
          "></div>
          <div style="flex: 1;">
            <div style="font-weight: 600; margin-bottom: 4px; font-size: 14px; letter-spacing: -0.2px;">
              Redirecting to result #${index}
            </div>
            <div style="font-size: 12px; opacity: 0.7; font-weight: 500;">
              <span id="lucky-countdown">${delay / 1000}</span>s remaining
            </div>
          </div>
        </div>
        <div style="
          font-size: 12px;
          opacity: 0.6;
          margin-bottom: 12px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          padding: 8px 10px;
          background: rgba(255, 255, 255, 0.05);
          border-radius: 4px;
          font-family: 'SF Mono', Monaco, 'Cascadia Code', monospace;
        " title="${resultUrl}">
          ${resultUrl}
        </div>
        <div style="
          font-size: 12px;
          opacity: 0.8;
          padding: 8px 10px;
          background: rgba(255, 255, 255, 0.08);
          border-radius: 4px;
          text-align: center;
          border: 1px solid rgba(255, 255, 255, 0.1);
        ">
          Click the icon in address bar or press <strong style="font-weight: 600;">ESC</strong> to cancel
        </div>
      </div>`;

    document.body.appendChild(notification);

    // Countdown
    let remaining = delay / 1000;
    const countdownEl = document.getElementById("countdown");
    countdownInterval = setInterval(() => {
      remaining -= 0.1;
      if (remaining > 0 && countdownEl) {
        countdownEl.textContent = remaining.toFixed(1);
      }
    }, 100);

    return notification;
  }

  function hideRedirectNotification() {
    const notification = document.getElementById("search-notification");
    if (notification) {
      notification.querySelector("div").classList.add("search-fade-out");
      setTimeout(() => notification.remove(), 300);
    }
  }

  function showCancelledMessage() {
    const cancelled = document.createElement("div");
    cancelled.innerHTML = `
      <div style="
        position: fixed;
        top: 20px;
        right: 20px;
        background: #F44336;
        color: white;
        padding: 16px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        z-index: 999999;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 14px;
        font-weight: 500;
        animation: slideIn 0.3s ease;
      ">
        ⛔ Redirect cancelled
      </div>
    `;
    document.body.appendChild(cancelled);
    setTimeout(() => {
      const div = cancelled.querySelector("div");
      if (div) {
        div.style.animation = "slideOut 0.3s ease";
        setTimeout(() => cancelled.remove(), 300);
      }
    }, 2000);
  }

  function cancelRedirect() {
    redirectCancelled = true;

    if (redirectTimeout) {
      clearTimeout(redirectTimeout);
      redirectTimeout = null;
    }

    if (countdownInterval) {
      clearInterval(countdownInterval);
      countdownInterval = null;
    }

    hideRedirectNotification();
    showCancelledMessage();

    chrome.runtime.sendMessage({ action: "redirectCancelled" });
    sessionStorage.removeItem("SearchProcessed");
  }

  // Main redirect logic
  function attemptRedirect() {
    const searchEngine = detectSearchEngine();

    if (!searchEngine) {
      return;
    }

    const { key, engine } = searchEngine;

    // Check if this engine is enabled
    if (!config.enabledEngines[key]) {
      return;
    }

    // Check if search query exists
    if (!hasSearchQuery(engine)) {
      return;
    }

    // Check if we've already processed this page
    if (sessionStorage.getItem("SearchProcessed") === window.location.href) {
      return;
    }

    // Mark as processed
    sessionStorage.setItem("SearchProcessed", window.location.href);

    // Wait a bit for results to load
    setTimeout(() => {
      if (redirectCancelled) return;

      const resultUrl = extractNthResult(engine, config.resultIndex);

      if (resultUrl) {
        console.log(`Search: Found result #${config.resultIndex}:`, resultUrl);

        // Notify background script to show page action
        chrome.runtime.sendMessage({
          action: "redirecting",
          index: config.resultIndex,
          url: resultUrl,
        });

        // Show notification
        showRedirectNotification(resultUrl, config.resultIndex, 3000);

        // Redirect after delay
        redirectTimeout = setTimeout(() => {
          if (!redirectCancelled) {
            console.log("i am not uncertain: Redirecting now...");
            window.location.href = resultUrl;
            chrome.runtime.sendMessage({ action: "redirectComplete" });
          }
        }, 3000);
      } else {
        console.log(
          `i am not uncertain: Could not find result #${config.resultIndex}`
        );
        sessionStorage.removeItem("luckySearchProcessed");
        chrome.runtime.sendMessage({ action: "redirectFailed" });
      }
    }, 500);
  }

  // Listen for cancel message from background (page action click)
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "cancelRedirect") {
      cancelRedirect();
    }
  });

  // Listen for ESC key to cancel
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && redirectTimeout) {
      cancelRedirect();
    }
  });

  // Load settings and run
  chrome.storage.sync.get(
    ["enabled", "resultIndex", "enabledEngines", "showNotification"],
    (result) => {
      config.enabled = result.enabled !== false;
      config.resultIndex = result.resultIndex || 1;
      config.enabledEngines = result.enabledEngines || {};
      config.showNotification = result.showNotification !== false;

      // Enable all engines by default on first run
      if (Object.keys(config.enabledEngines).length === 0) {
        for (const key of Object.keys(SEARCH_ENGINES)) {
          config.enabledEngines[key] = true;
        }
      }

      if (config.enabled) {
        attemptRedirect();
      }
    }
  );

  // Listen for settings changes
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "sync") {
      if (changes.enabled) {
        config.enabled = changes.enabled.newValue;
      }
      if (changes.resultIndex) {
        config.resultIndex = changes.resultIndex.newValue;
      }
      if (changes.enabledEngines) {
        config.enabledEngines = changes.enabledEngines.newValue;
      }
      if (changes.showNotification) {
        config.showNotification = changes.showNotification.newValue;
      }
    }
  });
})();
